import './App.css';
import Movie from './components/Movies/Movie';
import { Input, Tabs } from 'antd';

function App() {
  return (
    <div className="App">
      <div className="wrapper">
        <Tabs
          defaultActiveKey="1"
          centered
          size="large"
          items={[
            {
              key: '1',
              label: 'Search',
            },
            {
              key: '2',
              label: 'Rated',
            },
          ]}
        />
        <Input placeholder="Type to search..." className="search-input" />
        <Movie />
      </div>
    </div>
  );
}

export default App;
