import React, { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { Rate, ConfigProvider, Pagination } from 'antd';
import Genre from '../Genre/Genre';
import Loader from '../Loader/Loader'
import './movie.css';
import ErrorIndicator from '../ErrorIndicator/ErrorIndicator';

export default function Movie() {
  const [movieList, setMovieList] = useState([]);
  const [totalResults, setTotalResults] = useState([]);
  const [searchMovie, setSearchMovie] = useState([])
  const [current, setCurrent] = useState(1);
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  const onError = (error) => {
    setError(true)
    setLoading(false)
  }

  const onChangePage = (page) => {
    fetch(`https://api.themoviedb.org/3/discover/movie?api_key=514672082404a98e787157e73017cdb5&page=${page}`)
      .then((res) => res.json())
      .then((json) => {
        setTotalResults(json.total_pages);
        setMovieList(json.results);
        setLoading(false)
      })
      .catch(onError);
    setCurrent(page);
  };

  const getMovie = () => {
    fetch(`https://api.themoviedb.org/3/discover/movie?api_key=514672082404a98e787157e73017cdb5`)
      .then((res) => res.json())
      .then((json) => {
        setTotalResults(json.total_pages);
        setMovieList(json.results);
        setLoading(false)
      })
      .catch(onError);
  };

  const findMovie = () => {
    fetch(`https://api.themoviedb.org/3/search/movie?api_key=514672082404a98e787157e73017cdb5&query=${searchMovie}`)
    .then((res) => res.json())
    .then((json) => {
      setSearchMovie(json)
      setTotalResults(json.total_pages);
      setMovieList(json.results);
      setLoading(false)
      console.log(searchMovie)
    })
    .catch(onError);
  }

  function truncateAtWord(str, max, ellipsis = '…') {
    if (str.length <= max) return str;
    let trimmed = str.substr(0, max);
    if (str[max] !== ' ') {
      trimmed = trimmed.substr(0, Math.min(trimmed.length, trimmed.lastIndexOf(' ')));
    }
    return trimmed + ellipsis;
  }

  useEffect(() => {
    getMovie();
    // findMovie();
  }, []);

  if (loading) {
    return <Loader />
  }

  if (error) {
    <ErrorIndicator />
  }

  return (
    <>
      <ul>
        {movieList.map((movie) => (
          <li key={movie.id}>
            <div className="poster">
              <img
                style={{ width: '183px', height: '281px' }}
                src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                alt="movie"
              />
            </div>
            <div className="desc">
              <div className="title-wrapper">
                <h5>{movie.title}</h5>
                <div className="rating">
                  <p className="vote_average">{Number(movie.vote_average).toFixed(1)}</p>
                </div>
              </div>
              <p className="release_date">{format(new Date(movie.release_date ? movie.release_date : null), 'MMMM dd, yyyy')}</p>
              <Genre genreIds={movie.genre_ids} />
              <p>{truncateAtWord(movie.overview, 207)}</p>
              <div className="rated_stars">
                {
                  <ConfigProvider
                    theme={{
                      components: {
                        Rate: {
                          starSize: 15,
                        },
                      },
                    }}
                  >
                    <Rate allowHalf defaultValue={2.5} count={10} className="stars" />
                  </ConfigProvider>
                }
              </div>
            </div>
          </li>
        ))}
      </ul>
      <Pagination
        className="pagination-movies"
        align="center"
        defaultCurrent={1}
        current={current}
        onChange={onChangePage}
        total={totalResults}
        showLessItems
        size="small"
      />
    </>
  );
}
